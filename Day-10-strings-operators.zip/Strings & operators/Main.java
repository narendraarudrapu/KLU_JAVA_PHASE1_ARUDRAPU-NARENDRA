/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*import java.util.*;
class Main
{
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String rev = "";
        int i;
        for(i=s.length()-1;i>=0;i--)
        rev = rev+s.charAt(i);
        if(s.equals(rev))
        {
            System.out.print("The given number is a string Palindrome");
        } else {
            System.out.print("The  given number is not String Palindrome");
        }
    }
} */
// Tail recursion

/*import java.util.*;
class Main{
    static void fun(int n)
    {
        if(n>0)
        {
            System.out.println(n);
            fun(n-1);
        }
    }
public static void main(String[]args){
    Scanner obj = new Scanner(System.in);
    int n = obj.nextInt();
    fun(n);
 }
} */

// Head recursion
/*import java.util.*;
class Main {
    static void fun(int n)
    {
        if(n>0)
        {
            fun(n-1);
            System.out.print(n);
            System.out.println(n+1);
        }
    }
    public static void main(String[]args){
        Scanner obj= new Scanner(System.in);
        int n = obj.nextInt();
        fun(n);
    }
} */
// Linear recursion

/*import java.util.*;
class Main {
    static int fact(int n)
    {
        if(n==0 || n==1)
        return 1;
        return n*fact(n-1);
    }
    public static void main(String[]args){
        Scanner obj= new Scanner(System.in);
        int n = obj.nextInt();
        int ans=fact(n);
        System.out.println(ans);
    }
} */
//Nested Recursion

/*import java.util.*;
class Main {
    static int fun(int n);
    {
        if(n>100)
        {
        return n-10;
        return fun(fun(n+11));
    }
    public static void main(String[]args){
        int ans=fun(98);
        System.out.println(ans);
    }
} 
} */
/*import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
		int i;
		int arr[]= new int[n];
		for(i=0;i<n;i++)
		    arr[i]=sc.nextInt();
		    int ind=sc.nextInt();
		    int val=sc.nextInt();
		    arr[ind]=val;
		    for(i=0;i<n;i++)
		    System.out.print(arr[i] + " ");
		
	}
} */
// single inheritance
/*import java.util.*;

        class father{
            void gen2(){
                System.out.println("Gold");
            }
        }
            class  son extends father
            {
                void gen3(){
                    System.out.println("Cash");
                }
            }
            class Main {
            public static void main(String[]args)
            {
            son obj = new son();
            obj.gen3();
            obj.gen2();
            father f = new father();
            obj.gen2();
    }
                
            } */
// multilevel inheritance

 /*import java.util.*;

    class Grandfather{
    void gen1(){
    System.out.println("daimonds");
        }
    }
            class  father extends Grandfather
            {
                void gen2(){
                    System.out.println("Gold");
                }
            }
            class son extends father{
                void gen3()
                {
                    System.out.println("Cash");
                }
            }
            class Main {
            public static void main(String[]args)
            {
            son obj = new son();
            obj.gen3();
            obj.gen2();
            obj.gen1();
            father f = new father();
            obj.gen2();
            obj.gen1();
            Grandfather g = new Grandfather();
            obj.gen1();
    }
                
            }
            */
// Hierarchical inheritance
/*import java.util.*;

    class father{
    void gen1(){
    System.out.println("daimonds");
        }
    }
            class  son extends father
            {
                void gen2(){
                    System.out.println("Gold");
                }
            }
            class Daughter extends father{
                void gen3()
                {
                    System.out.println("Cash");
                }
            }
            class Main {
            public static void main(String[]args)
            {
            son obj = new son();
            obj.gen2();
            obj.gen1();
            Daughter s = new Daughter();
            s.gen3();
            s.gen1();
           
    }
                
            } */
    /*        public class Main {
    public static void main(String[] args) {

        for (int i = 2; i <= 10; i++) {
            int count = 0;

            for (int j = 1; j <= i; j++) {
                if (i % j == 0) {
                    count++;
                }
            }

            if (count == 2) {
                System.out.print(i + " ");
            }
        }
    }
} */
/*import java.util.*;
class codechef{
    void display(int a)
    {
        System.out.println("Integer data:"+a);
    }
    void display(float b)
{
    System.out.println("float data:"+b);
}
public static void main(String[] args)
{
    Scanner sc = new Scanner(System.in);
    codechef c = new codechef();
    int a = sc.nextInt();
    float b = sc.nextfloat();
    c.display(a);
    c.display(b);
}
} */
// Singlely Linked List

// import java.util.*;
// class Node{
//     int data;
//     Node next;
//     Node(int d){
//         this.data=d;
//         this.next=null;
//     }
// }
// class Main{
//     Node first;
//     void insert(int d){
//         Node n=new Node(d);
//         if(first==null)
//         {
//             first=n;
//             return;
//         }
//         else
//         {
//             Node temp=first;
//             while(temp.next!=null){
//                 temp=temp.next;
//             }
//             temp.next=n;
//         }
        
//     }
//     void display(){
//         if(first==null){
//             System.out.print("Linked List is Empty");
//             return;
//         }
//         Node temp = first;
//             while(temp!=null){
//                 System.out.print(temp.data+" ");
//                 temp=temp.next;
//             }
//     }
//     public static void main(String[]args){
//         Scanner sc = new Scanner(System.in);
//         Main m = new Main();
//         int d=sc.nextInt();
//         while (d != -1){
//             m.insert(d);
//             d=sc.nextInt();
//         }
//         m.display();
//     }
// }

// Sum of the elements in the linked list


// import java.util.*;
// class Node{
//     int data;
//     Node next;
//     Node(int d){
//         this.data=d;
//         this.next=null;
//     }
// }
// class Main{
//     Node first;
//     void insert(int d){
//         Node n=new Node(d);
//         if(first==null)
//         {
//             first=n;
//             return;
//         }
//         else
//         {
//             Node temp=first;
//             while(temp.next!=null){
//                 temp=temp.next;
//             }
//             temp.next=n;
//         }
        
//     }
//     void sumelements(){
//         int sum=0;
//         if(first==null){
//             System.out.print("Linked List is Empty");
//             return;
//         }
//         Node temp = first;
//             while(temp!=null){
//                 sum+=temp.data;
//                 temp=temp.next;
//             }
//             System.out.print(sum+" ");
//     }
//     public static void main(String[]args){
//         Scanner sc = new Scanner(System.in);
//         Main m = new Main();
//         int d=sc.nextInt();
//         while (d != -1){
//             m.insert(d);
//             d=sc.nextInt();
//         }
//         m.sumelements();
//     }
// }


// Finding the maximum element in the linked List


// Singlely Linked List

/*import java.util.*;
class Node{
    int data;
     Node next;
    Node(int d){
         this.data=d;
         this.next=null;
    }
}
 class Main{
     Node first;
     void insert(int d){
        Node n=new Node(d);
        if(first==null)
        {
           first=n;
            return; 
            }
         else
         {
             Node temp=first;
            while(temp.next!=null){
                 temp=temp.next;
             }
             temp.next=n;
         }
        
     }
     void display(){
         if(first==null){
             System.out.print("Linked List is Empty");
             return;
         }
         Node temp = first;
             while(temp!=null){
                 System.out.print(temp.data+" ");
                 temp=temp.next;
             }
     }
     public static void main(String[]args){
         Scanner sc = new Scanner(System.in);
         Main m = new Main();
         int d=sc.nextInt();
         while (d != -1){
             m.insert(d);
            d=sc.nextInt();
            }
         m.display();
     }
 }*/
 
 //Sum of the elements in the linked list


/*import java.util.*;
 class Node{
     int data;
     Node next;
     Node(int d){
         this.data=d;
         this.next=null;
     }
 }
 class Main{
     Node first;
     void insert(int d){
         Node n=new Node(d);
         if(first==null)
         {
             first=n;
             return;
         }
         else
         {
             Node temp=first;
             while(temp.next!=null){
                 temp=temp.next;
             }
             temp.next=n;
         }
        
     }
     void sumelements(){
         int sum=0;
         if(first==null){
             System.out.print("Linked List is Empty");
             return;
         }
         Node temp = first;
             while(temp!=null){
                 sum+=temp.data;
                 temp=temp.next;
             }
             System.out.print(sum+" ");
     }
     public static void main(String[]args){
         Scanner sc = new Scanner(System.in);
         Main m = new Main();
         int d=sc.nextInt();
         while (d != -1){
            m.insert(d);
             d=sc.nextInt();
         }
         m.sumelements();
     }
 } */
 // Finding the maximum element in the linked List


/*import java.util.*;
class Node{
    int data;
    Node next;
    Node(int d){
        this.data=d;
        this.next=null;
    }
}
class Main{
    Node first;
    void insert(int d){
        Node n=new Node(d);
        if(first==null)
        {
            first=n;
            return;
        }
        else
        {
            Node temp=first;
            while(temp.next!=null){
                temp=temp.next;
            }
            temp.next=n;
        }
        
    }
    void maxele(){
        int max=Integer.MIN_VALUE;
        if(first==null){
            System.out.print("Linked List is Empty");
            return;
        }
        Node temp = first;
            while(temp!=null){
                max=temp.data;
                temp=temp.next;
            }
            System.out.print(max+" ");
    }
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        Main m = new Main();
        int d=sc.nextInt();
        while (d != -1){
            m.insert(d);
            d=sc.nextInt();
        }
        m.maxele();
    }
} */
// find the minimum element in the linked List

/*import java.util.*;
class Node{
    int data;
    Node next;
    Node(int d){
        this.data=d;
        this.next=null;
    }
}
class Main{
    Node first;
    void insert(int d){
        Node n=new Node(d);
        if(first==null)
        {
            first=n;
            return;
        }
        else
        {
            Node temp=first;
            while(temp.next!=null){
                temp=temp.next;
            }
            temp.next=n;
        }
        
    }
    void minele(){
        int min=Integer.MAX_VALUE;
        if(first==null){
            System.out.print("Linked List is Empty");
            return;
        }
        Node temp = first;
            while(temp!=null){
                if(temp.data<min)
                min=temp.data;
                temp=temp.next;
            }
            System.out.print(min+" ");
    }
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        Main m = new Main();
        int d=sc.nextInt();
        while (d != -1){
            m.insert(d);
            d=sc.nextInt();
        }
        m.minele();
    }
} */
// find the average element in the linked list

/* import java.util.*;
class Node{
    int data;
    Node next;
    Node(int d){
        this.data=d;
        this.next=null;
    }
}
class Main{
    Node first;
    void insert(int d){
        Node n=new Node(d);
        if(first==null)
        {
            first=n;
            return;
        }
        else
        {
            Node temp=first;
            while(temp.next!=null){
                temp=temp.next;
            }
            temp.next=n;
        }
        
    }
    void avg(){
        int sum=0;
        int count = 0;
        if(first==null){
            System.out.print("Linked List is Empty");
            return;
        }
        Node temp = first;
            while(temp!=null){
                count++;
                sum+=temp.data;
                temp=temp.next;
            }
            System.out.print( sum / count+" ");
    }
    public static void main(String[]args){
        Scanner sc = new Scanner(System.in);
        Main m = new Main();
        int d=sc.nextInt();
        while (d != -1){
            m.insert(d);
            d=sc.nextInt();
        }
        m.avg();
    }
} */

/* import java.util.Scanner;

class Node {
    int data;
    Node next;
    Node(int data) {
        this.data = data;
        this.next = null;
    }
}
public class Main {
    Node head;

    
    void insertEnd(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            return;
        }

        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }

        temp.next = newNode;
    }

    void insertAtPosition(int data, int position) {
        Node newNode = new Node(data);

        if (position == 1) {
            newNode.next = head;
            head = newNode;
            return;
        }

        Node temp = head;

        for (int i = 1; i < position - 1 && temp != null; i++) {
            temp = temp.next;
        }

        if (temp == null) {
            System.out.println("Invalid Position");
            return;
        }

        newNode.next = temp.next;
        temp.next = newNode;
    }

    
    void display() {
        Node temp = head;

        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }

        System.out.println();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Main list = new Main();

        System.out.print("Enter number of nodes: ");
        int n = sc.nextInt();

        System.out.println("Enter elements:");
        for (int i = 0; i < n; i++) {
            list.insertEnd(sc.nextInt());
        }

        System.out.print("Enter element to insert: ");
        int data = sc.nextInt();

        System.out.print("Enter position: ");
        int pos = sc.nextInt();

        list.insertAtPosition(data, pos);

        System.out.println("Linked List after insertion:");
        list.display();
    }
} */
//circular linked list

/*import java.util.*;
class Node{
    int data;
    Node prev;
    Node next;
    Node(int d){
        this.data = d;
        this.prev = null;
        this.next = null;
    }
}
class main{
    Node first;
    void insert(int value);
    Node n = new Node(value);
    if(first == null)
    first = n;
   } else {
        Node temp = first;
        while(temp.next != null)
        temp = temp.next;
        temp.next = n;
        n.prev = temp;
    }
} */
/*import java.util.*;
class Node
{
    int data;
    Node next;
    Node(int d)
    {
        this.data = d;
        this.next = null;
    }
}
class Main{
    Node first;
    void insert(int d){
        Node n = new Node(d);
        if(first==null){
            first = n;
            n.next = first;
        }else{
            Node temp = first;
            while(temp.next!=first){
                temp=temp.next;
            }
            temp.next = n;
            n.next=first;
        }
        
    }
    void display(){
        if(first == null){
        System.out.print("Linked List is Enpty");
        return;
        }
        Node temp=first;
        do{
            System.out.print(temp.data+" ");
            temp = temp.next;
        }while(temp!=first);
        
    }
    public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        int d=sc.nextInt();
        Main m = new Main();
        while(d!=-1){
            m.insert(d);
            d=sc.nextInt();
        }
        m.display();
    }
}*/  
/*
import java.util.*;
class Node{
    int data;
    Node next;
    Node prev;
    Node(int d){
        this.data = d;
        this.next = null;
        this.prev = null;
    }
}
class Main{
    
    Node  first;
    void insert(int value) {
        Node n = new Node(value);
        if(first == null){
            first = n;
            n.next=frist;
            n.prev=frist;
        }else{
            Node last = first.prev;
            last.next=n;
            n.prev=last;
            n.next=first;
            frist.prev=n;
        }
        void display()
        {
            if(first==null){
                System.out.print("Linked list is empty");
                return;
            }
            Node temp=first;
            do
            {
                System.out.print(temp.data+" ");
                temp=temp.next;
            }while(temp!=first);
        }
    }
} */