/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
		int i;
		int arr[]= new int[n];
		for(i=0;i<n;i++)
		    arr[i]=sc.nextInt();
		    int ind=sc.nextInt();
		    int val=sc.nextInt();
		    arr[ind]=val;
		    for(i=0;i<n;i++)
		    System.out.print(arr[i] + " ");
		
	}
} */
/*import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
		int i,flag=0;
		int arr[]= new int[n];
		for(i=0;i<n;i++)
		    arr[i]=sc.nextInt();
		    int s=sc.nextInt();
		    for(i=0;i<n;i++)
		        if(arr[i]==s)
		        {
		            System.out.print("Present");
		            flag=1;
		            break;
		        }
		        if(flag==0)
		            System.out.print("Not present");
		   }
} */
/*import java.util.*;
class Main
{
    public static void main(String[]args)
    {
        Scanner sc = new Scanner(System.in);
            int n = sc.nextInt();
            int arr[]=new int[n];
            int i,zc=0,oc=0;
            for(i=0;i<n;i++)
            {
                arr[i]=sc.nextInt();
                if(arr[i]==0)
                zc++;
            }
            for(i=0;i<zc;i++)
            arr[i]=0;
            for(i=zc;i<n;i++)
            arr[i]=1;
            for(i=0;i<n;i++)
            
            System.out.print(arr[i]+" ");
}
}
import java.util.*;
public static void main(String[]args){
class Stack
{
    int top;
    int arr[];
    int size;
    int i;
    Stack(int n)
    {
        this.top=-1;
        this.size=n;
        arr=new int[n];
    }
    void push(int d)
    {
        if(top==-1)
        {
            System.out.print("stack overflow");
        }
        else
        {
            arr[++top]=d;
            System.out.print(arr[top]);
        }
    }
    void pop()
    {
        if(top==-1)
        System.out.print("stack underflow");
        else
        System.out.print(arr[i]);
    }
    void peek()
    {
        if(top==-1)
        System.out.print("selectbunderflow");
        else
        System.out.print(arr[top]);
    }
    void display()
    {
        if(top==-1)
        System.out.print("stack underflow");
        for(i=top;i>=0;i--)
        System.out.print(arr[i]+"");
    }
   
    }
    
} */
//  Queue with array
/*import java.util.*;
class Queue{
    int front, rear;
    int n;
    int arr[];
    Queue(int n){
        this.n = n;
        arr = new int[n];
        front = 0;
        rear = -1;
    }
    void enqueue(int data){
        if(rear == n-1){
            System.out.print("Queue id full");
            return;
        }
        arr[++rear] = data;{
            System.out.print(arr[rear]);
        }
    }
    void dequeue(){
        if(front>rear){
            System.out.print("Queue is empty");
            return;
        }
        System.out.println(arr[front++]);
    }
    void display(){
        if(front>rear){
            System.out.print("Queue is emoty");
            return;
        }
        for(int i = front;i<=rear;i++){
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
}
public class Main{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        Queue q = new Queue(n);
        while(true){
            System.out.print("\n1.Enqueue");
            System.out.print("2. Dequeue");
            System.out.print("3.Display");
            System.out.print("4. Exit");
            System.out.print("Enter choice");
            int choice = sc.nextInt();
            switch (choice)
            {
                case 1:
                    System.out.print("Enter value of enqueue: ");
                    int val = sc.nextInt();
                    q.enqueue(val);
                    break;
                case 2:
                    q.dequeue();
                    break;
                case 3:
                    q.display();
                    break;
                case 4:
                    System.out.println("Existing.....");
                    return;
                default:
                    System.out.print("Invalid");
            }
        }
    }
}