/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// print array Elements

public class Main {
    public static void main(String[] args) {

        int[] arr = {10, 20, 30, 40, 50};

        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
    }
}
// Find the largest Elements
public class Main {
    public static void main(String[] args) {

        int[] arr = {10, 25, 15, 40, 30};

        int max = arr[0];

        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }

        System.out.println("Largest = " + max);
    }
}

//Find the smallest element
public class Main {
    public static void main(String[] args) {

        int[] arr = {10, 25, 15, 40, 30};

        int min = arr[0];

        for (int i = 1; i < arr.length; i++) {
            if (arr[i] < min) {
                min = arr[i];
            }
        }

        System.out.println("Smallest = " + min);
    }
}
//Find the sum of array Elements
public class Main {
    public static void main(String[] args) {

        int[] arr = {10, 20, 30, 40};

        int sum = 0;

        for (int i = 0; i < arr.length; i++) {
            sum = sum + arr[i];
        }

        System.out.println("Sum = " + sum);
    }
}
// Reverse an  array
public class Main {
    public static void main(String[] args) {

        int[] arr = {10, 20, 30, 40, 50};

        for (int i = arr.length - 1; i >= 0; i--) {
            System.out.print(arr[i] + " ");
        }
    }
}
// Find the second Largest element
public class Main {
    public static void main(String[] args) {

        int[] arr = {10, 50, 30, 40, 20};

        int largest = arr[0];
        int second = arr[0];

        for (int i = 1; i < arr.length; i++) {

            if (arr[i] > largest) {
                second = largest;
                largest = arr[i];
            } else if (arr[i] > second && arr[i] != largest) {
                second = arr[i];
            }
        }

        System.out.println("Second Largest = " + second);
    }
}
// Remove duplicates
public class Main {
    public static void main(String[] args) {

        int[] arr = {1, 2, 2, 3, 4, 4};

        for (int i = 0; i < arr.length; i++) {

            boolean duplicate = false;

            for (int j = 0; j < i; j++) {
                if (arr[i] == arr[j]) {
                    duplicate = true;
                    break;
                }
            }

            if (!duplicate)
                System.out.print(arr[i] + " ");
        }
    }
}
// Find the second smallest elementpublic class Main {
    public static void main(String[] args) {

        int[] arr = {10, 50, 30, 40, 20};

        int smallest = arr[0];
        int second = Integer.MAX_VALUE;

        for (int i = 1; i < arr.length; i++) {

            if (arr[i] < smallest) {
                second = smallest;
                smallest = arr[i];
            } else if (arr[i] < second && arr[i] != smallest) {
                second = arr[i];
            }
        }

        System.out.println("Second Smallest = " + second);
    }
}
// count even & odd numbers
public class Main {
    public static void main(String[] args) {

        int[] arr = {10, 15, 20, 25, 30};

        int even = 0, odd = 0;

        for (int i = 0; i < arr.length; i++) {

            if (arr[i] % 2 == 0)
                even++;
            else
                odd++;
        }

        System.out.println("Even = " + even);
        System.out.println("Odd = " + odd);
    }
}