/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int start = sc.nextInt();
        int end = sc.nextInt();

        for (int i = start; i <= end; i++) {
            if (i % 2 == 0) {
                System.out.print(i + " ");
            }
        }
    }
}

import java.util.*;
class Main
{
	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		int n = obj.nextInt();
		int col,row;
		for(row =0;row < n;row++,System.out.println()){
		    for (col = 0; col<n-row;col++)
		    System.out.print("*");
		}
		
	}
} 
import java.util.*;
class Main
{
	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		int n = obj.nextInt();
		int col,row;
		for(row =0;row < n;row++,System.out.println()){
		    for (col = 0; col<n-row-1;col++)
		    System.out.print(" ");
		    for(col=0;col<n;col++)
		    System.out.print("*");
		}
		
	}
}
public class Main
{
	public static void main(String[] args) {
	   Scanner sc = new Scanner(System.in);
	 int n = obj.nextInt();
	 int i;
	 for(i = 1;i <= n/2;i++)
	 {
	     if(n%i==0)
	     System.out.print(i+"");
	}
	System.out.print(n);
  }
}


